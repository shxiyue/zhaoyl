变更：
ELK版本为5.3.0（官网最新）
新增CentOS部分
修改hosts，新增server_ip
更新elk_init.sh，适应多版本，优化日志打印
更新elasticsearch，新增JAVA_HOME
更新elasticsearch.yml，kibana.yml，新增server_ip
联调测试