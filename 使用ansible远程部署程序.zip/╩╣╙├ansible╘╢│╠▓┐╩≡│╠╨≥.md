![](media/28a1a92f4eeeecd842fd166fd2b3143e.jpg)

使用ansible远程部署程序

上海玺玥信息科技有限公司

目 录

[目 录 i](#_Toc477964217)

[1. Ansible基础介绍 2](#ansible基础介绍)

[1.1. 简介 2](#简介)

[1.2. Ansible总体架构 2](#ansible总体架构)

[1.3. Ansible特点 3](#ansible特点)

[1.4. Ansible优点 3](#ansible优点)

[1.5. 任务执行流程 4](#任务执行流程)

[2. Ansible安装 4](#ansible安装)

[2.1. 基础环境要求 4](#基础环境要求)

[2.1.1. 对管理主机的要求 4](#对管理主机的要求)

[2.1.2. 对托管节点的要求 4](#对托管节点的要求)

[2.2. 安装 5](#安装)

[2.2.1. Ubuntu 5](#ubuntu)

[2.2.2. Linux 5](#linux)

[2.2.3. 源码安装 5](#源码安装)

[2.3. Ansible配置 5](#ansible配置)

[2.3.1. 配置SSH免密码登录 5](#配置ssh免密码登录)

[2.3.2. 远程部署ELK 6](#远程部署elk)

1.  Ansible基础介绍

    1.  简介

ansible是新出现的自动化运维工具，基于Python开发，集合了众多运维工具（puppet、cfengine、chef、func、fabric）的优点，实现了批量系统配置、批量程序部署、批量运行命令等功能。ansible是基于模块工作的，本身没有批量部署的能力。真正具有批量部署的是ansible所运行的模块，ansible只是提供一种框架。主要包括：

(1)、连接插件connection plugins：负责和被监控端实现通信；

(2)、host inventory：指定操作的主机，是一个配置文件里面定义监控的主机；

(3)、各种模块核心模块、command模块、自定义模块；

(4)、借助于插件完成记录日志邮件等功能；

(5)、playbook：剧本执行多个任务时，非必需可以让节点一次性运行多个任务。

Ansible总体架构
---------------

![](media/66e4fa5b1d999d025b777d693bb0dfe6.png)

Ansible特点
-----------

(1)、no agents：不需要在被管控主机上安装任何客户端；

(2)、no server：无服务器端，使用时直接运行命令即可；

(3)、modules in any languages：基于模块工作，可使用任意语言开发模块；

(4)、yaml，not code：使用yaml语言定制剧本playbook；

(5)、ssh by default：基于SSH工作；

(6)、strong multi-tier solution：可实现多级指挥。

Ansible优点
-----------

(1)、轻量级，无需在客户端安装agent，更新时，只需在操作机上进行一次更新即可；

(2)、批量任务执行可以写成脚本，而且不用分发到远程就可以执行；

(3)、使用python编写，维护更简单，ruby语法过于复杂；

(4)、支持sudo。

任务执行流程
------------

![](media/6376ff7fb18bed2d5933172c13953334.png)

Ansible安装
===========

基础环境要求
------------

### 对管理主机的要求

目前,只要机器上安装了 Python 2.6 或 Python 2.7
(windows系统不可以做控制主机),都可以运行Ansible.

主机的系统可以是 Red Hat, Debian, CentOS, OS X, BSD的各种版本,等等.

自2.0版本开始,ansible使用了更多句柄来管理它的子进程,对于OS
X系统,你需要增加ulimit值才能使用15个以上子进程,方法 sudo launchctl limit
maxfiles 1024 2048,否则你可能会看见”Too many open file”的错误提示.

### 对托管节点的要求

通常我们使用 ssh 与托管节点通信，默认使用 sftp.如果 sftp 不可用，可在
ansible.cfg 配置文件中配置成 scp 的方式. 在托管节点上也需要安装 Python 2.4
或以上的版本.如果版本低于 Python 2.5 ,还需要额外安装一个模块:

python-simplejson

注：

可以使用python –V命令检查python版本，预计的返回如下

![](media/cc8e779ab4fa010c8a41405e5fe6a45c.png)

如果python版本不符合，可以使用ansible myhost --sudo -m raw -a "yum install -y
python2 python-simplejson" 命令通过管理主机远程在托管节点安装Python 2.X 和
simplejson 模块.

安装
----

### Ubuntu

sudo apt install ansible

### Linux

sudo yum install ansible

### 源码安装

Ansible配置
-----------

### 配置SSH免密码登录

#### 常规方式

**1. 生成公钥/私钥**

使用ssh-keygen -t
rsa命令，会在当前用户的根目录下生成.ssh文件夹，id\_rsa为生成的公钥文件，id\_rsa.pub为生成的私钥文件。

![](media/e68cf32ce06d628a26d547c1b1b7c466.png)

![](media/31f480875f9533f4d0e94e01304deb06.png)

2. 将id\_rsa.pub至目标机器/.ssh/authorized\_keys中（没有就新建）

#### 批量添加脚本

###  远程部署ELK

#### 配置hosts

修改/etc/ansible/hosts文件，新增组和主机名，每个自定义组可包含多个主机名，ansible运行时可以直接指定组执行命令。下面的例子为添加了一个名为slavenode的组，并且添加了一台IP为10.10.9.139的机器。

![](media/434e8431c76e7020e8255facc4dc1905.png)

#### 测试连接

这里使用ansible slavenode -m command -a
'hostname'命令测试连接。连接成功返回值如下。

![](media/eaa955fa7e23c5742906597f5fc18e26.png)

参考：

注意：这里使用ansible slavenode -m
setup可以返回一些远程主机的基本信息，而这些信息都是可以在之后被ansible使用的，比如下图中ansible\_all\_ipv4\_addresses，ansible\_bios\_version等参数，之后都可以作为ansible定制化部署的限定参数。

![](media/6a1bd17c5c531de838181ae2cd072339.png)

#### 配置ansible playbook

ansible 的配置文件为 ansible
playbook，该文件采用YAML语法结构，即所有成员都开始于相同的缩进级别。

Ansible提供了很多模块，例如复制文件（copy），检测主机运行状态（ping）等，查看ansible模块可以使用ansible-doc
–l命令。

举例：

在目标服务器新建用户，该例子使用root用户在slavenode组中的服务器新建一个名为zhaoyl的用户。

\- name: create user

hosts: slavenode

user: root

gather\_facts: false

vars:

\- user: "zhaoyl"

tasks:

\- name: create {{ user }}

user: name="{{ user }}"

执行结果：

![](media/674f9dacfe40cbdfffd9b28837fc51f0.png)

目标服务器：

![](media/1cf5efac1b563e5a3930b7709e9a7246.png)

#### Elk配置文件

在执行elk.yml时遇到报错“fatal: [10.10.9.139]: UNREACHABLE! =\> {"changed":
false, "msg": "ERROR! SSH encountered an unknown error during the connection. We
recommend you re-run the command using -vvvv, which will enable SSH debugging
output to help diagnose the issue", "unreachable": true}”

解决：

1.尝试ping远程主机

/etc/ansible\# ansible slavenode -m ping

10.10.9.139 \| SUCCESS =\> {

"changed": false,

"ping": "pong"

}

2.查看elk.yml文件，remote\_user写的是name用户，而免密登录配的是root导致的问题，添加name用户的免密登录之后，问题解决。

The error was: ERROR! error while evaluating conditional (logstash or
elasticsearch or kibana): ERROR! 'logstash' is undefined\\n\\nThe error appears
to have been in '/etc/ansible/elk.yml': line 25, column 9, but may\\nbe
elsewhere in the file depending on the exact syntax problem.\\n\\nThe offending
line appears to be:\\n\\n\\

解决：

该报错为/etc/ansible/hosts中未定义logstash or elasticsearch or
kibana参数，在/etc/ansible/hosts中添加kibana=true elasticsearch=true
logstash=true即可。

#### 使用ansible安装jdk

替换jdk的例子：

\---

\#自动部署配置,jdk

\#

\#主机名

\- hosts: slavenode

\#gather\_facts: False

vars:

srcsoftdir: "/home/zhaoyl/open\_source/soft/" \#安装源目录

desthomedir: "/home/name/elk" \#目标目录

elkVersion: "5.2.1"

esVersion: "5.2.1"

logstashVersion: "5.2.1"

kibanaVersion: "5.2.1"

jdkVersion: "jdk-8u121-linux-x64"

remote\_user: root

tasks:

\- name : create-dir

file : path={{item}} state=directory mode=0755

with\_items:

\- "{{ desthomedir }}"

\- "{{ desthomedir }}/opt"

\- "{{ desthomedir }}/conf"

\- "{{ desthomedir }}/depkit"

\- name : put-jdk

copy: src={{ srcsoftdir }}/depkit/jdk-8u121-linux-x64.tar.gz dest={{ desthomedir
}}/depkit mode="u=rwx"

with\_items:

\- "jdk-{{jdkVersion}}"

when: logstash or elasticsearch or kibana

\- name : unzip-jdk

command : tar -zxf {{desthomedir}}/depkit/jdk-8u121-linux-x64.tar.gz -C
{{desthomedir}}/opt

with\_items:

\- "jdk-{{jdkVersion}}"

when: logstash or elasticsearch or kibana

\- name: java

lineinfile: dest=/etc/profile backrefs=yes regexp="JAVA\_HOME=" line="export
JAVA\_HOME=/usr/java/jdk1.8.0\_121"

\- name: java

lineinfile: dest=/etc/profile backrefs=yes regexp="CLASS\_PATH=" line="export
CLASS\_PATH=.:\$JAVA\_HOME/lib.tools.jar"

\- name : java

lineinfile: dest=/etc/profile backrefs=yes regexp="PATH=\\\$JAVA\_HOME:\\\$PATH"
line="export PATH=\$PATH:\$JAVA\_HOME/bin"

说明：

ansible-doc lineinfile

替换 移除文件的单行 \# 多行替换 移除参考replace模块

Options: (= is mandatory)(= 后面的参数是强制要有的)

\- backrefs(default=no)

　　与state=present一起使用

　　一、支持反向引用

　　二、稍微改变了模块的操作方式

　　1、前插'insertbefore'，后插'insertafter'失效

　　2、如果匹配到 替换最后一个匹配结果

　　3、如果未匹配到 不做任何改变

= dest

　　被编辑的文件

\- insertafter

　　需要声明 state=present

　　在匹配行后插入，如果未匹配到则默认为EOF。ps:如果line存在则不会再插入，不管regexp有没有匹配到

\- insertbefore

　　需要声明 state=present

　　在匹配行前插入，如果未匹配到则默认为BOF。ps:如果line存在则不会再插入，不管regexp有没有匹配到

\- line

　　需要声明 state=present

　　插入或替换的字符串

\- regexp

　　使用正则匹配

\- state(default=present)

　　present 如果匹配到就替换(最后一个匹配结果) \#如果未设置backrefs=yes
未匹配到也会在最后插入line

　　absent 移除匹配行(所有匹配到的)

#### 远程部署elk

代码示例：

\---

\#自动部署配置,elk

\#

\#主机名

\- hosts: tgtnode

\#gather\_facts: False

vars:

srcsoftdir: "/home/zhaoyl/open\_source/soft/" \#安装源目录

desthomedir: "/home/bitmap/elk" \#目标目录

elkVersion: "5.2.1"

esVersion: "5.2.1"

logstashVersion: "5.2.1"

kibanaVersion: "5.2.2"

jdkVersion: "jdk-8u121-linux-x64"

remote\_user: bitmap

tasks:

\- name : create-dir

file : path={{item}} state=directory mode=0755

with\_items:

\- "{{ desthomedir }}"

\- "{{ desthomedir }}/opt"

\- "{{ desthomedir }}/conf"

\- "{{ desthomedir }}/depkit"

\- "{{ desthomedir }}/logs"

\- "{{ desthomedir }}/depscript"

\#----------------elasticsearch config ----------------------------------

\- name : put-es

copy: src={{ srcsoftdir }}/depkit/{{item}}.zip dest={{ desthomedir }}/depkit
mode="0755"

with\_items:

\- "elasticsearch-{{elkVersion}}"

when:

\- elasticsearch

\- ansible\_distribution == 'SLES' and ansible\_distribution\_major\_version ==
"11"

\- name : unzip-elasticsearch

command : unzip {{desthomedir}}/depkit/{{item}}.zip -d {{desthomedir}}/opt

with\_items:

\- "elasticsearch-{{elkVersion}}"

when : elasticsearch

\- name : put-esconfig

template: src={{ srcsoftdir }}/conf/{{item}}
dest={{desthomedir}}/opt/elasticsearch-{{elkVersion}}/config mode=0755

with\_items:

\- "elasticsearch.yml"

when:

\- elasticsearch

\- name : put-elk\_init

template: src={{ srcsoftdir }}/depscript/{{item}}.sh dest={{ desthomedir
}}/depscript/ mode="0755"

with\_items:

\- "elk\_init"

when:

\- elasticsearch or kibana or logstash

\- name: start-es

shell: sh {{ desthomedir }}/depscript/elk\_init.sh elasticsearch start

when: logstash or elasticsearch or kibana

\#----------------kibana config ----------------------------------

\- name : put-kibana

copy: src={{ srcsoftdir }}/depkit/{{item}}.tar.gz dest={{ desthomedir }}/depkit
mode="0755"

with\_items:

\- "kibana-{{kibanaVersion}}"

when:

\- kibana

\- ansible\_distribution == 'SLES' and ansible\_distribution\_major\_version ==
"11"

\- name : unzip-kibana

command : tar -zxvf {{desthomedir}}/depkit/{{item}}.tar.gz -C
{{desthomedir}}/opt

with\_items:

\- "kibana-{{kibanaVersion}}"

when : kibana

\- name : put-kibanaconfig

template: src={{ srcsoftdir }}/conf/{{item}}
dest={{desthomedir}}/opt/kibana-{{kibanaVersion}}/config mode=0755

with\_items:

\- "kibana.yml"

when:

\- kibana

\- name : put-elk\_init

template: src={{ srcsoftdir }}/depscript/{{item}}.sh dest={{ desthomedir
}}/depscript/ mode="0755"

with\_items:

\- "elk\_init"

when:

\- elasticsearch or kibana or logstash

\- name: start-kibana

shell: sh {{ desthomedir }}/depscript/elk\_init.sh kibana start 5601

when: logstash or elasticsearch or kibana

\#----------------logstash config ----------------------------------

\- name : put-logstash

copy: src={{ srcsoftdir }}/depkit/{{item}}.zip dest={{ desthomedir }}/depkit
mode="0755"

with\_items:

\- "logstash-{{logstashVersion}}"

when:

\- logstash

\- ansible\_distribution == 'SLES' and ansible\_distribution\_major\_version ==
"11"

\- name : unzip-logstash

command : unzip {{desthomedir}}/depkit/{{item}}.zip -d {{desthomedir}}/opt

with\_items:

\- "logstash-{{logstashVersion}}"

when : logstash

\- name : put-logstashconfig

template: src={{ srcsoftdir }}/conf/{{item}}
dest={{desthomedir}}/opt/kibana-{{kibanaVersion}}/config mode=0755

with\_items:

\- "logstash.yml"

when:

\- logstash

\- name : put-elk\_init

template: src={{ srcsoftdir }}/depscript/{{item}}.sh dest={{ desthomedir
}}/depscript/ mode="0755"

with\_items:

\- "elk\_init"

when:

\- elasticsearch or kibana or logstash

中间用到的shell源码：

zhaoyl\@zhaoyl-virtual-machine:\~/open\_source/soft/depscript\$ cat
remove\_jdk.sh

\#!/bin/bash

\#remove jdk if exists

echo 111111

for i in \$(rpm -qa \| grep jdk \| grep -v grep)

do

rpm -e --nodeps \$i

echo \`date +%Y-%m-%d-%T \` "--\> Jdk has been uninstall."

done

if [[ ! -z \$(rpm -qa \| grep jdk \| grep -v grep) ]];

then

echo \`date +%Y-%m-%d-%T\` "--\>The system has no defult Jdk."

Fi

zhaoyl\@zhaoyl-virtual-machine:\~/open\_source/soft/depscript\$ cat elk\_init.sh

\#!/bin/bash

\#start or stop elk

\_Help()

{

cat \<\<!

Usage

elk\_init.sh \<product\> \<pro\_status\> \<logstashfile\>\|\<kibanaport\>

exp

sh elk\_init.sh elasticsearch start

Parameters of the usage:

product : elasticsearch\|kibana\|logstash

pro\_status : start\|stop

logstashfile : /home/zhaoyl/open\_source/logstash-5.2.1/bin/logstash.conf (full
path)

kibanaport : default 5601

!

exit 21

}

\_Echf()

{

u\_MsgType=\$1

u\_Msg=\$2

u\_MsgHead=""

u\_ResCode=255

Time=\`date "+%Y/%m/%d %H:%M:%S"\`

case \${u\_MsgType} in

M) u\_MsgHead=" [M] [\$Time]"

u\_ResCode=0

;;

W) u\_MsgHead=" \*[W] [\$Time]"

u\_ResCode=11

;;

E) u\_MsgHead="\*\*[Err] [\$Time]"

u\_ResCode=255

;;

SYS)u\_MsgHead="\*\*[SYS] [\$Time]"

u\_ResCode=0

;;

NH) u\_MsgHead=""

u\_Msg="\${u\_Msg} "

u\_ResCode=0

;;

CLE)u\_MsgHead=""

\>\$LogPatch/\$LogFileName

u\_ResCode=0

;;

TIT)u\_ShellRunTimes=0

u\_MsgHead=""

u\_ShellRunTimes=\`grep 'ShellRunTimes:[0-9]' \$LogPatch/\$LogFileName
2\>\>/dev/null \| awk -F ':' '{gsub("-","");print \$2}'\|wc -l \`

u\_ShellRunTimes=\`echo "\${u\_ShellRunTimes}+1" \|bc \`

u\_Msg="\\n\\n-----------------------------------------------
ShellRunTimes:\${u\_ShellRunTimes}
-----------------------------------------------"

u\_ResCode=0

;;

\*) u\_Msg="\*\*[Err] [\$Time]"

u\_Msg="Message type Input Error MsgType:[\${u\_MsgType}]"

u\_ResCode=21

;;

esac

echo -e "\${u\_Msg}" \| while read u\_Once

do

echo -e "\${u\_MsgHead} \${u\_Once}" \| tee -a \$LogPatch/\$LogFileName

done

if [ \$? -ne 0 ]

then

echo "The log file output failure"

exit 254

fi

return \${u\_ResCode}

}

\#set env

BizDate=\`date +%Y%m%d\`

LogPatch={{desthomedir}}/logs

LogFileName="elk\_init\_\${BizDate}.log"

BasePath={{desthomedir}}

logstash\_file=\${LogPatch}/logstash.pid

elasticsearch\_file=\${LogPatch}/elasticsearch.pid

kibana\_file=\${LogPatch}/kibana.pid

kibana\_log=\${LogPatch}/kibana.log

JAVA\_HOME=\`echo \$JAVA\_HOME\`

\#check param

if [ \$\# -lt 2 ]

then

echo "Number of parameters is not correct"

\_Help

fi

\#set param

product=\$1

pro\_status=\$2

logstashfile=""

kibanaport=""

\_Echf TIT

case \$1 in

logstash)

if [ "\${pro\_status}"X == "stop"X ]

then sleep 0.5

else if [ "\${pro\_status}"X == "start"X ] && [ -n "\${3}" ] ;then

logstashfile=\$3

else \_Help

fi

fi

;;

kibana)

if [ "\${pro\_status}"X == "stop"X ]

then sleep 0.5

else if [ "\${pro\_status}"X == "start"X ] && [ -n "\${3}" ] ;then

kibanaport=\$3

else \_Help

fi

fi

;;

elasticsearch)

sleep 0.5

;;

\*)

\_Help

;;

esac

if [ \${product} = "logstash" ] ; then

case \${pro\_status} in

start)

nohup sh \${BasePath}/opt/logstash-5.2.1/bin/logstash -f \${logstashfile}
1\>/dev/null 2\>&1 &

sleep 3

logstash\_pid=\`ps -ef \|grep -i logstash \|grep -v grep\|grep -v \$0\|awk
'{print \$2}'\`

\# echo \`ps -ef \|grep -i logstash \|grep -v grep\|grep -v \$0\`

if [ ! -z "\${logstash\_pid}" ] ; then

echo \$logstash\_pid\>\$logstash\_file

\_Echf "M" "Start Logstash successful PID:\${logstash\_pid}"

else \_Echf "E" "Start Logstash fail,please check Logstash log
:\${BasePath}/opt/logstash-5.2.1/logs"

fi

;;

stop)

cat \${logstash\_file} \|xargs kill

if [ \$? -le 1 ] ; then

\_Echf "M" "Stop Logstash successful "

else \_Echf "E" "Stop Logstash fail,please check Logstash log
:\${BasePath}/opt/logstash-5.2.1/logs"

fi

;;

\*)

\_Help

exit 1

;;

esac

else if [ \${product} = "elasticsearch" ] ; then

case \${pro\_status} in

start)

nohup \${BasePath}/opt/elasticsearch-5.2.1/bin/elasticsearch -d &

sleep 10

elasticsearch\_pid=\`jps \| grep -i elasticsearch \| grep -v grep \| awk '{print
\$1}'\`

if [ ! -z \${elasticsearch\_pid} ] ; then

echo \$elasticsearch\_pid\>\$elasticsearch\_file

\_Echf "M" "Start elasticsearch successful PID:\${elasticsearch\_pid}"

else \_Echf "E" "Start elasticsearch fail,please check elasticsearch log
:\${BasePath}/opt/elasticsearch-5.2.1/logs"

fi

;;

stop)

cat \${elasticsearch\_file} \|xargs kill

if [ \$? -le 1 ] ; then

\_Echf "M" "Stop elasticsearch successful "

else \_Echf "E" "Stop elasticsearch fail,please check elasticsearch log
:\${BasePath}/opt/elasticsearch-5.2.1/logs"

fi

;;

\*)

\_Help

exit 2

;;

esac

else

case \${pro\_status} in

start)

nohup sh \${BasePath}/opt/kibana-5.2.2/bin/kibana 1\>\${kibana\_log} 2\>&1 &

sleep 3

fuser -n tcp \${kibanaport} 1\>\${kibana\_file} 2\>/dev/null

kibana\_pid=\`cat \${kibana\_file} \|sed 's/ //g'\`

if [ ! -z \${kibana\_pid} ] ; then

\_Echf "M" "Start kibana successful PID:\${kibana\_pid}"

else \_Echf "E" "Start kibana fail,please check kibana log :\${kibana\_log}"

fi

;;

stop)

cat \${kibana\_file} \|sed 's/ //g' \|xargs kill

if [ \$? -le 1 ] ; then

\_Echf "M" "Stop kibana successful "

else \_Echf "E" "Stop kibana fail,please check kibana log :\${kibana\_log}"

fi

;;

\*)

\_Help

exit 3

;;

esac

fi

fi

exit \$?
